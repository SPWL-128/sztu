#!/usr/bin/env python3
import rclpy
from geometry_msgs.msg import PoseStamped
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
from tf2_ros import TransformListener, Buffer
from tf_transformations import euler_from_quaternion, quaternion_from_euler
from rclpy.duration import Duration

class AutoPatrolNode(BasicNavigator):
    def __init__(self, node_name='auto_patrol_node'):
        super().__init__(node_name)
        
        # 导航相关参数定义
        self.declare_parameter('initial_point', [0.0, 0.0, 0.0])
        self.declare_parameter('target_points', [
            0.0, 0.0, 0.0,
            1.0, 2.0, 3.14,
            -4.5, 1.5, 1.57,
            -8.0, -5.0, 1.57,
            1.0, -5.0, 3.14,
        ])
        
        # 从参数服务器获取参数值
        self.initial_point_ = self.get_parameter('initial_point').value
        self.target_points_ = self.get_parameter('target_points').value
        
        # TF变换监听器，用于获取实时位置
        self.buffer_ = Buffer()
        self.listener_ = TransformListener(self.buffer_, self)
        
        self.get_logger().info("自动巡逻节点已初始化")

    def get_pose_by_xyyaw(self, x, y, yaw):
        """
        通过 x, y, yaw 合成 PoseStamped
        """
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.position.z = 0.0
        
        # 将欧拉角转换为四元数
        rotation_quat = quaternion_from_euler(0, 0, yaw)
        pose.pose.orientation.x = rotation_quat[0]
        pose.pose.orientation.y = rotation_quat[1]
        pose.pose.orientation.z = rotation_quat[2]
        pose.pose.orientation.w = rotation_quat[3]
        
        return pose

    def init_robot_pose(self):
        """
        初始化机器人位姿
        """
        self.get_logger().info("开始初始化机器人位姿...")
        
        # 从参数获取初始化点
        self.initial_point_ = self.get_parameter('initial_point').value
        
        # 合成位姿并进行初始化
        initial_pose = self.get_pose_by_xyyaw(
            self.initial_point_[0], 
            self.initial_point_[1], 
            self.initial_point_[2]
        )
        
        self.setInitialPose(initial_pose)
        
        # 等待直到导航系统激活
        self.waitUntilNav2Active()
        self.get_logger().info("机器人位姿初始化完成")

    def get_target_points(self):
        """
        从参数值获取目标点集合        
        """
        points = []
        self.target_points_ = self.get_parameter('target_points').value
        
        # 每3个值代表一个目标点 (x, y, yaw)
        point_count = len(self.target_points_) // 3
        
        for index in range(point_count):
            x = self.target_points_[index * 3]
            y = self.target_points_[index * 3 + 1]
            yaw = self.target_points_[index * 3 + 2]
            points.append([x, y, yaw])
            self.get_logger().info(f'获取到目标点 {index + 1}: (x={x:.2f}, y={y:.2f}, yaw={yaw:.2f})')
        
        return points

    def nav_to_pose(self, target_pose):
        """
        导航到指定位姿
        """
        self.get_logger().info("等待导航系统激活...")
        self.waitUntilNav2Active()
        
        self.get_logger().info(f"开始导航到目标点: "
                               f"x={target_pose.pose.position.x:.2f}, "
                               f"y={target_pose.pose.position.y:.2f}")
        
        # 开始导航
        self.goToPose(target_pose)
        
        # 等待导航完成
        while not self.isTaskComplete():
            # 获取导航反馈
            feedback = self.getFeedback()
            if feedback:
                remaining_time = Duration.from_msg(feedback.estimated_time_remaining).nanoseconds / 1e9
                self.get_logger().info(f'预计 {remaining_time:.1f} 秒后到达目标点')
        
        # 获取最终结果
        result = self.getResult()
        
        if result == TaskResult.SUCCEEDED:
            self.get_logger().info('✅ 导航成功到达目标点')
        elif result == TaskResult.CANCELED:
            self.get_logger().warn('⚠️ 导航被取消')
        elif result == TaskResult.FAILED:
            self.get_logger().error('❌ 导航失败')
        else:
            self.get_logger().error('❓ 导航返回无效状态')

    def get_current_pose(self):
        """
        通过TF获取当前机器人位姿
        """
        try:
            # 获取从map到base_footprint的变换
            tf = self.buffer_.lookup_transform(
                'map', 
                'base_footprint', 
                rclpy.time.Time(seconds=0), 
                rclpy.time.Duration(seconds=1)
            )
            
            transform = tf.transform
            
            # 将四元数转换为欧拉角
            rotation_euler = euler_from_quaternion([
                transform.rotation.x,
                transform.rotation.y,
                transform.rotation.z,
                transform.rotation.w
            ])
            
            self.get_logger().info(
                f'当前位姿 - 位置: (x={transform.translation.x:.2f}, y={transform.translation.y:.2f}), '
                f'方向: (yaw={rotation_euler[2]:.2f})'
            )
            
            return transform
            
        except Exception as e:
            self.get_logger().warn(f'无法获取坐标变换: {str(e)}')
            return None

def main(args=None):
    rclpy.init(args=args)
    
    # 创建巡逻节点
    patrol = AutoPatrolNode()
    
    try:
        # 初始化机器人位姿
        patrol.get_logger().info("正在初始化机器人位姿...")
        patrol.init_robot_pose()
        patrol.get_logger().info("位置初始化完成")
        
        # 开始巡逻循环
        patrol.get_logger().info("开始自动巡逻任务...")
        
        while rclpy.ok():
            # 获取目标点列表
            target_points = patrol.get_target_points()
            
            if not target_points:
                patrol.get_logger().error("没有找到目标点，请检查参数配置")
                break
            
            # 依次导航到每个目标点
            for i, point in enumerate(target_points):
                x, y, yaw = point[0], point[1], point[2]
                
                patrol.get_logger().info(f"准备前往目标点 {i + 1}: (x={x:.2f}, y={y:.2f})")
                
                # 创建目标位姿
                target_pose = patrol.get_pose_by_xyyaw(x, y, yaw)
                
                # 导航到目标点
                patrol.nav_to_pose(target_pose)
                
                # 到达目标点后暂停一下
                patrol.get_logger().info(f"已到达目标点 {i + 1}，暂停3秒...")
                rclpy.spin_once(patrol, timeout_sec=3.0)
            
            patrol.get_logger().info("完成一轮巡逻，开始下一轮...")
            
    except KeyboardInterrupt:
        patrol.get_logger().info("收到中断信号，停止巡逻...")
    except Exception as e:
        patrol.get_logger().error(f"巡逻过程中发生错误: {str(e)}")
    finally:
        # 清理资源
        patrol.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
