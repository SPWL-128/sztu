#!/usr/bin/env python3
"""
渐进式转向自动建图节点
每次检测到前方0.5米有墙就后退0.1米，右转10度，直到和墙平行
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import numpy as np
import math
import time
from collections import deque
from rclpy.qos import qos_profile_sensor_data

class IncrementalTurnFollower(Node):
    def __init__(self):
        super().__init__('incremental_turn_follower')
        
        # ====================== 安全参数 ======================
        self.front_safe = 0.4      # 前方安全距离
        self.side_safe = 0.4       # 侧方安全距离
        self.emergency_stop = 0.3  # 紧急停止距离
        
        # ====================== 沿墙参数 ======================
        self.wall_distance = 0.5   # 目标墙距
        self.wall_gap_threshold = 1.0  # 检测到墙的最大距离
        
        # ====================== 控制参数 ======================
        self.normal_speed = 0.15
        self.slow_speed = 0.08
        self.turn_speed = 0.3      # 转向速度
        self.backup_speed = -0.1
        
        # ====================== 渐进转向参数 ======================
        self.front_wall_threshold = 0.5    # 前方有墙的阈值
        self.backup_distance = 0.1         # 后退距离（米）
        self.turn_angle_increment = 10.0   # 每次转向角度（度）
        self.turn_angle_increment_rad = math.radians(self.turn_angle_increment)
        
        # ====================== 状态管理 ======================
        self.state = "INIT"
        self.state_start_time = time.time()
        self.wall_side = "right"  # 沿右侧墙
        
        # 渐进转向相关
        self.turn_count = 0               # 转向次数
        self.total_turned_angle = 0.0     # 累计转向角度
        self.last_yaw = 0.0               # 上次的偏航角
        self.is_aligned_with_wall = False # 是否已与墙平行
        
        # ====================== 方向校准 ======================
        self.front_idx = 0      # 0° - 正前方
        self.left_idx = 89      # 90° - 正左侧
        self.right_idx = 269    # 270° - 正右侧
        self.back_idx = 179     # 180° - 正后方
        
        # ====================== 数据存储 ======================
        self.laser_data = None
        self.robot_pose = None
        self.start_time = time.time()
        self.distance_history = deque(maxlen=10)
        
        # ====================== 发布订阅 ======================
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        self.laser_sub = self.create_subscription(
            LaserScan, '/scan', self.laser_callback, 
            qos_profile=qos_profile_sensor_data)
        
        # ====================== 定时器 ======================
        self.control_timer = self.create_timer(0.1, self.control_loop)
        self.status_timer = self.create_timer(2.0, self.status_report)
        
        self.get_logger().info("🔄 渐进式转向自动建图节点启动")
        self.get_logger().info("策略：前方有墙 → 后退0.1m → 右转10° → 重复直到平行")
    
    def laser_callback(self, msg):
        """激光雷达回调"""
        self.laser_data = msg
        
        # 转换数据
        ranges = np.array(msg.ranges, dtype=np.float32)
        ranges = np.where(np.isinf(ranges), msg.range_max, ranges)
        ranges = np.where(np.isnan(ranges), msg.range_max, ranges)
        
        num_points = len(ranges)
        
        # 获取各个方向的距离
        front_distance = ranges[self.front_idx] if self.front_idx < num_points else msg.range_max
        left_distance = ranges[self.left_idx] if self.left_idx < num_points else msg.range_max
        right_distance = ranges[self.right_idx] if self.right_idx < num_points else msg.range_max
        back_distance = ranges[self.back_idx] if self.back_idx < num_points else msg.range_max
        
        # 前方区域（正前方±15度）用于紧急检测
        emergency_sector = []
        
        # 添加345°到360°（索引345到359）
        for i in range(345, 360):
            if i < num_points:
                emergency_sector.append(ranges[i])
        
        # 添加0°到15°（索引0到14）
        for i in range(0, 15):
            if i < num_points:
                emergency_sector.append(ranges[i])
        
        emergency_min = np.min(emergency_sector) if len(emergency_sector) > 0 else msg.range_max
        
        # 前方区域（正前方±30度）用于前进决策
        front_sector = []
        
        # 添加330°到360°（索引330到359）
        for i in range(330, 360):
            if i < num_points:
                front_sector.append(ranges[i])
        
        # 添加0°到30°（索引0到29）
        for i in range(0, 30):
            if i < num_points:
                front_sector.append(ranges[i])
        
        front_min = np.min(front_sector) if len(front_sector) > 0 else msg.range_max
        
        # 检查是否与墙平行（右侧有墙且前方没有墙）
        has_right_wall = right_distance < self.wall_gap_threshold
        has_front_wall = front_min < self.front_wall_threshold
        
        # 保存分析结果
        self.laser_analysis = {
            'front': float(front_distance),
            'left': float(left_distance),
            'right': float(right_distance),
            'back': float(back_distance),
            'front_min': float(front_min),
            'emergency_min': float(emergency_min),
            'emergency': emergency_min < self.emergency_stop,
            'obstacle_front': front_min < self.front_safe,
            'obstacle_left': left_distance < self.side_safe,
            'obstacle_right': right_distance < self.side_safe,
            'wall_on_right': has_right_wall,
            'wall_on_left': left_distance < self.wall_gap_threshold,
            'front_clear': front_min > self.front_safe * 1.5,
            'wall_in_front': front_min < self.front_wall_threshold,  # 前方0.5米内有墙
            'has_right_wall': has_right_wall,
            'has_front_wall': has_front_wall,
            'is_aligned': has_right_wall and not has_front_wall,  # 已与墙平行
            'range_max': msg.range_max
        }
        
        # 调试输出
        self.get_logger().info(
            f"激光: 前={front_distance:.2f}m | 右={right_distance:.2f}m | "
            f"前方有墙:{front_min<0.5} | 已平行:{has_right_wall and not has_front_wall}",
            throttle_duration_sec=0.5
        )
    
    def update_robot_pose(self):
        """更新机器人位姿（简化版）"""
        # 在实际应用中，这里应该从odom话题获取
        # 这里我们使用简单的积分来估算
        current_time = time.time()
        
        if not hasattr(self, 'last_pose_update_time'):
            self.last_pose_update_time = current_time
            self.robot_yaw = 0.0
            self.robot_x = 0.0
            self.robot_y = 0.0
            return
        
        # 简单积分（仅用于转向角度估计）
        dt = current_time - self.last_pose_update_time
        self.last_pose_update_time = current_time
        
        # 如果有cmd_vel数据，可以积分
        if hasattr(self, 'last_twist'):
            twist = self.last_twist
            self.robot_yaw += twist.angular.z * dt
        
        # 保存到robot_pose
        self.robot_pose = {
            'x': self.robot_x,
            'y': self.robot_y,
            'yaw': self.robot_yaw,
            'time': current_time
        }
    
    def control_loop(self):
        """主控制循环 - 渐进式转向"""
        if self.state == "FINISH":
            return
        
        if not hasattr(self, 'laser_analysis'):
            if self.state == "INIT":
                self.init_behavior()
            return
        
        analysis = self.laser_analysis
        twist = Twist()
        
        # 保存当前的twist用于积分
        self.last_twist = twist
        
        # 更新机器人位姿
        self.update_robot_pose()
        
        # 检查紧急情况（最高优先级）
        if analysis['emergency']:
            self.get_logger().warn(f"🚨 紧急停止！距离={analysis['emergency_min']:.2f}m")
            self.state = "EMERGENCY_STOP"
            self.state_start_time = time.time()
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.cmd_vel_pub.publish(twist)
            return
        
        # 状态机
        if self.state == "INIT":
            self.init_behavior()
            return
        
        elif self.state == "GO_STRAIGHT":
            self.go_straight_behavior(twist, analysis)
        
        elif self.state == "BACK_AND_TURN":
            self.back_and_turn_behavior(twist, analysis)
        
        elif self.state == "ALIGN_WITH_WALL":
            self.align_with_wall_behavior(twist, analysis)
        
        elif self.state == "FOLLOW_WALL":
            self.follow_wall_behavior(twist, analysis)
        
        elif self.state == "TURN_CORNER":
            self.turn_corner_behavior(twist, analysis)
        
        elif self.state == "EMERGENCY_STOP":
            self.emergency_stop_behavior(twist, analysis)
        
        else:
            self.get_logger().error(f"未知状态: {self.state}")
            self.state = "GO_STRAIGHT"
        
        self.cmd_vel_pub.publish(twist)
        
        # 状态转换检查
        self.check_state_transition(analysis)
    
    def init_behavior(self):
        """初始化行为"""
        current_time = time.time()
        elapsed = current_time - self.state_start_time
        
        twist = Twist()
        
        if elapsed < 2.0:
            # 等待传感器初始化
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.get_logger().info("初始化: 等待传感器...")
        else:
            # 重置转向计数器
            self.turn_count = 0
            self.total_turned_angle = 0.0
            self.is_aligned_with_wall = False
            
            # 进入直行模式
            self.state = "GO_STRAIGHT"
            self.state_start_time = current_time
            self.get_logger().info("初始化完成，开始直行")
        
        self.cmd_vel_pub.publish(twist)
    
    def go_straight_behavior(self, twist, analysis):
        """直行行为"""
        current_time = time.time()
        elapsed = current_time - self.state_start_time
        
        # 检查是否已经与墙平行
        if analysis['is_aligned']:
            self.get_logger().info("✅ 已与墙平行，开始沿墙行走")
            self.state = "ALIGN_WITH_WALL"
            self.state_start_time = current_time
            return
        
        # 检查前方是否有墙（距离<0.5米）
        if analysis['wall_in_front']:
            self.get_logger().info(f"检测到前方墙壁，距离={analysis['front_min']:.2f}m，准备后退和转向")
            self.state = "BACK_AND_TURN"
            self.state_start_time = current_time
            return
        
        # 检查是否超时
        if elapsed > 30.0:
            self.get_logger().info("直行30秒未找到墙，尝试右转找墙")
            self.state = "BACK_AND_TURN"
            self.state_start_time = current_time
            return
        
        # 简单直行
        twist.linear.x = self.normal_speed
        twist.angular.z = 0.0
        
        # 每5秒报告一次
        if elapsed % 5.0 < 0.1:
            self.get_logger().info(f"直行中: 前方距离={analysis['front']:.2f}m")
    
    def back_and_turn_behavior(self, twist, analysis):
        """后退并转向行为（每次10度）"""
        current_time = time.time()
        elapsed = current_time - self.state_start_time
        
        # 第一阶段：后退0.1米（约0.7秒）
        if elapsed < 0.7:
            twist.linear.x = self.backup_speed
            twist.angular.z = 0.0
            self.get_logger().info("后退: 远离墙壁")
        
        # 第二阶段：右转10度（约0.3秒）
        elif elapsed < 1.0:
            twist.linear.x = 0.0
            twist.angular.z = -self.turn_speed  # 右转
            self.get_logger().info(f"右转{self.turn_angle_increment}度")
            
            # 记录转向
            if not hasattr(self, 'has_recorded_turn'):
                self.turn_count += 1
                self.total_turned_angle += self.turn_angle_increment_rad
                self.has_recorded_turn = True
                self.get_logger().info(f"累计转向: {self.turn_count}次, {math.degrees(self.total_turned_angle):.0f}度")
        
        # 第三阶段：返回直行，检查是否已平行
        else:
            # 重置记录标记
            self.has_recorded_turn = False
            
            # 检查是否已转向太多（超过180度）
            if self.total_turned_angle > math.radians(180):
                self.get_logger().info("已转向超过180度，强制进入沿墙模式")
                self.state = "ALIGN_WITH_WALL"
                self.state_start_time = current_time
            else:
                # 返回直行模式
                self.state = "GO_STRAIGHT"
                self.state_start_time = current_time
                self.get_logger().info(f"转向完成，返回直行（已转向{math.degrees(self.total_turned_angle):.0f}度）")
    
    def align_with_wall_behavior(self, twist, analysis):
        """与墙对齐行为"""
        current_time = time.time()
        elapsed = current_time - self.state_start_time
        
        # 检查是否真的已平行（右侧有墙且前方没有墙）
        if analysis['is_aligned']:
            # 与墙平行，前进一小段距离确认
            if elapsed < 2.0:
                twist.linear.x = self.slow_speed
                twist.angular.z = 0.0
                self.get_logger().info("与墙平行，前进确认...")
            else:
                # 确认完成，进入沿墙模式
                self.is_aligned_with_wall = True
                self.state = "FOLLOW_WALL"
                self.state_start_time = current_time
                self.get_logger().info("确认完成，开始沿墙行走")
        else:
            # 失去平行状态，返回渐进转向
            self.get_logger().info("失去平行状态，返回渐进转向")
            self.state = "GO_STRAIGHT"
            self.state_start_time = current_time
    
    def follow_wall_behavior(self, twist, analysis):
        """沿墙行走行为"""
        # 检查前方是否有障碍（需要左转）
        if analysis['obstacle_front']:
            self.get_logger().info(f"前方障碍，距离={analysis['front_min']:.2f}m，准备左转")
            self.state = "TURN_CORNER"
            self.state_start_time = time.time()
            return
        
        # 检查是否失去右侧墙
        if not analysis['wall_on_right']:
            self.get_logger().warn("失去了右侧墙，尝试重新对齐")
            self.is_aligned_with_wall = False
            self.state = "GO_STRAIGHT"
            self.state_start_time = time.time()
            return
        
        # 沿墙控制
        wall_distance = analysis['right']
        target_distance = self.wall_distance
        
        # 计算误差
        error = wall_distance - target_distance
        
        # 基础速度
        twist.linear.x = self.normal_speed
        
        # PID控制
        if error < -0.1:  # 太近（小于0.4米）
            twist.angular.z = 0.15  # 左转远离墙
        elif error > 0.1:  # 太远（大于0.6米）
            twist.angular.z = -0.1  # 右转向墙
        else:
            twist.angular.z = 0.0  # 直行
        
        # 记录历史
        self.distance_history.append(wall_distance)
        
        # 调试输出
        self.get_logger().info(
            f"沿墙: 墙距={wall_distance:.2f}m, 目标={target_distance:.2f}m, "
            f"误差={error:.2f}m",
            throttle_duration_sec=1.0
        )
    
    def turn_corner_behavior(self, twist, analysis):
        """转弯行为（遇到障碍左转）"""
        current_time = time.time()
        elapsed = current_time - self.state_start_time
        
        if elapsed < 2.0:  # 转弯2秒
            twist.linear.x = self.slow_speed * 0.5
            twist.angular.z = self.turn_speed  # 左转
            self.get_logger().info("转弯: 左转")
        else:
            # 转弯完成后检查
            if analysis['wall_on_right'] and not analysis['obstacle_front']:
                self.get_logger().info("转弯完成，继续沿墙")
                self.state = "FOLLOW_WALL"
                self.state_start_time = current_time
            else:
                self.get_logger().info("转弯后无法继续，重新对齐")
                self.is_aligned_with_wall = False
                self.state = "GO_STRAIGHT"
                self.state_start_time = current_time
    
    def emergency_stop_behavior(self, twist, analysis):
        """紧急停止行为"""
        current_time = time.time()
        elapsed = current_time - self.state_start_time
        
        if elapsed < 0.5:
            twist.linear.x = 0.0
            twist.angular.z = 0.0
            self.get_logger().info("紧急停止")
        elif elapsed < 1.5:
            twist.linear.x = self.backup_speed
            twist.angular.z = 0.0
            self.get_logger().info("后退")
        else:
            # 后退后重新开始渐进转向
            self.turn_count = 0
            self.total_turned_angle = 0.0
            self.is_aligned_with_wall = False
            self.state = "GO_STRAIGHT"
            self.state_start_time = current_time
    
    def check_state_transition(self, analysis):
        """检查状态转换"""
        current_time = time.time()
        state_duration = current_time - self.state_start_time
        
        # 防止状态卡死
        if state_duration > 30.0 and self.state in ["FOLLOW_WALL", "GO_STRAIGHT"]:
            self.get_logger().warn(f"状态 {self.state} 持续30秒，重新初始化")
            self.state = "INIT"
            self.state_start_time = current_time
        
        # 安全保护：如果任何状态下检测到紧急情况，立即停止
        if analysis['emergency'] and self.state != "EMERGENCY_STOP":
            self.get_logger().warn("安全保护：检测到紧急情况")
            self.state = "EMERGENCY_STOP"
            self.state_start_time = current_time
    
    def status_report(self):
        """状态报告"""
        if not hasattr(self, 'laser_analysis'):
            return
        
        analysis = self.laser_analysis
        current_time = time.time()
        run_time = current_time - self.start_time
        
        self.get_logger().info("=" * 60)
        self.get_logger().info(f"🔄 渐进式转向 - 运行时间: {run_time:.0f}秒")
        self.get_logger().info(f"当前状态: {self.state}")
        self.get_logger().info(f"前方距离: {analysis['front']:.2f}m")
        self.get_logger().info(f"右侧距离: {analysis['right']:.2f}m")
        self.get_logger().info(f"紧急距离: {analysis['emergency_min']:.2f}m")
        self.get_logger().info(f"前方有墙(<0.5m): {analysis['wall_in_front']}")
        self.get_logger().info(f"检测到右侧墙: {analysis['wall_on_right']}")
        self.get_logger().info(f"已与墙平行: {analysis['is_aligned']}")
        self.get_logger().info(f"转向次数: {self.turn_count}次")
        self.get_logger().info(f"累计转向角度: {math.degrees(self.total_turned_angle):.0f}°")
        
        if len(self.distance_history) > 0:
            avg = sum(self.distance_history) / len(self.distance_history)
            self.get_logger().info(f"平均墙距: {avg:.2f}m")
        
        self.get_logger().info("=" * 60)
        
        # 5分钟自动停止
        if run_time > 300:
            self.get_logger().info("✅ 探索时间达到5分钟，完成探索")
            self.state = "FINISH"
            self.stop_robot()
    
    def stop_robot(self):
        """停止机器人"""
        twist = Twist()
        self.cmd_vel_pub.publish(twist)
        self.get_logger().info("机器人已停止")


def main(args=None):
    rclpy.init(args=args)
    node = IncrementalTurnFollower()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("手动停止")
    finally:
        node.stop_robot()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
