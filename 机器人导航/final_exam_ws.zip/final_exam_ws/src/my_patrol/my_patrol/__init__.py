# my_patrol包初始化文件
