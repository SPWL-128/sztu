from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    
    # 启动仿真环境
    fishbot_description_dir = get_package_share_directory('fishbot_description')
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(fishbot_description_dir, 'launch', 'gazebo_sim.launch.py')
        )
    )
    
    # 启动导航（使用默认地图或指定地图）
    fishbot_nav_dir = get_package_share_directory('fishbot_navigation2')
    nav_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(fishbot_nav_dir, 'launch', 'navigation2.launch.py')
        ),
        launch_arguments={
            'use_sim_time': 'true'
        }.items()
    )
    
    # 启动你的巡逻节点
    patrol_node = Node(
        package='my_patrol',
        executable='patrol_node',
        name='my_patrol_node',
        output='screen'
    )
    
    return LaunchDescription([
        gazebo_launch,
        nav_launch,
        patrol_node,
    ])
