import os
import launch
import launch_ros
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    # 获取包路径
    nav_manager_dir = get_package_share_directory('navigation_manager')
    fishbot_nav_dir = get_package_share_directory('fishbot_navigation2')
    
    return launch.LaunchDescription([
        # Gazebo仿真
        launch.actions.IncludeLaunchDescription(
            launch.launch_description_sources.PythonLaunchDescriptionSource(
                [get_package_share_directory('fishbot_description'), '/launch/gazebo_sim.launch.py']
            )
        ),
        
        # 导航系统
        launch.actions.IncludeLaunchDescription(
            launch.launch_description_sources.PythonLaunchDescriptionSource(
                [fishbot_nav_dir, '/launch/navigation2.launch.py']
            ),
            launch_arguments={
                'use_sim_time': 'true'
            }.items()
        ),
        
        # RViz可视化
        launch_ros.actions.Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', os.path.join(nav_manager_dir, 'config', 'patrol_rviz.rviz')],
            parameters=[{'use_sim_time': True}],
            output='screen'
        )
    ])
