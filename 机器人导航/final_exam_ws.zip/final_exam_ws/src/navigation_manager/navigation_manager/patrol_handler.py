#!/usr/bin/env python3
"""
巡逻处理模块
负责巡逻过程的启动和管理
"""
import subprocess
import os
import time

class PatrolHandler:
    def __init__(self, terminal_manager, map_utils):
        self.terminal_manager = terminal_manager
        self.map_utils = map_utils
        self.patrol_processes = []
        
    def start_patrol_session(self, map_name):
        """启动巡逻会话，加载指定地图（全部使用root）"""
        print("="*60)
        print(f"开始巡逻会话，使用地图: {map_name}")
        print("所有终端将以root权限运行")
        print("="*60)
        
        # 检查地图文件
        is_valid, message = self.map_utils.check_map_files(map_name)
        if not is_valid:
            print(f"✗ {message}")
            return False
        
        # 获取工作空间目录
        ws_dir = "/home/vboxuser/final_exam_ws"
        
        try:
            # 终端1: Gazebo仿真 - 使用root终端
            print("\n启动Gazebo仿真（root权限）...")
            gazebo_process = self.terminal_manager.open_terminal_simple(
                title="Gazebo仿真 [ROOT]",
                command="ros2 launch fishbot_description gazebo_sim.launch.py",
                work_dir=ws_dir
            )
            self.patrol_processes.append(gazebo_process)
            time.sleep(15)
            
            # 检查Gazebo是否成功启动
            gazebo_ready = self.check_gazebo_ready()
            if not gazebo_ready:
                print("⚠️  Gazebo可能启动失败，尝试继续...")
            
            # 终端2: 导航系统 - 使用root终端
            print("启动导航系统（root权限）...")
            map_yaml_path = os.path.join(self.map_utils.maps_dir, f"{map_name}.yaml")
            nav_process = self.terminal_manager.open_terminal_simple(
                title="导航系统 [ROOT]",
                command=f"ros2 launch fishbot_navigation2 navigation2.launch.py use_sim_time:=true map:={map_yaml_path}",
                work_dir=ws_dir
            )
            self.patrol_processes.append(nav_process)
            time.sleep(10)
            
            # 终端3: RViz巡逻模式 - 使用root终端
            print("启动RViz巡逻（root权限）...")
            rviz_process = self.terminal_manager.open_terminal_simple(
                title="RViz巡逻 [ROOT]",
                command="rviz2 -d /home/vboxuser/final_exam_ws/src/navigation_manager/config/patrol_rviz.rviz",
                work_dir=ws_dir
            )
            self.patrol_processes.append(rviz_process)
            time.sleep(5)
            
            # 终端4: 巡逻节点 - 使用root终端
            print("启动自动巡逻节点（root权限）...")
            patrol_process = self.terminal_manager.open_terminal_simple(
                title="自动巡逻节点 [ROOT]",
                command="ros2 run auto_check auto_patrol_node",
                work_dir=ws_dir
            )
            self.patrol_processes.append(patrol_process)
            
            print("\n" + "="*60)
            print("✓ 巡逻环境已启动，打开4个终端（全部ROOT权限）：")
            print("  1. Gazebo仿真")
            print("  2. 导航系统")
            print("  3. RViz巡逻")
            print("  4. 自动巡逻节点")
            print("="*60)
            print(f"\n🤖 机器人正在使用地图 '{map_name}' 进行巡逻...")
            print("巡逻点: [0,0,0], [1,2,3.14], [-4.5,1.5,1.57], [-8,-5,1.57], [1,-5,3.14]")
            print("注意：所有终端都以root权限运行")
            print("="*60)
            
            return True
            
        except Exception as e:
            print(f"✗ 启动巡逻会话失败: {e}")
            return False
    
    def check_gazebo_ready(self):
        """检查Gazebo是否成功启动"""
        try:
            result = subprocess.run(
                "sudo pgrep -f gazebo",
                shell=True,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                pids = result.stdout.strip().split('\n')
                print(f"✓ Gazebo进程已启动 (PID: {', '.join(pids)})")
                return True
            else:
                print("⚠️  未找到Gazebo进程")
                return False
                
        except Exception as e:
            print(f"✗ 检查Gazebo状态失败: {e}")
            return False
    
    def stop_patrol_session(self):
        """停止巡逻会话"""
        print("\n正在停止巡逻会话...")
        
        try:
            # 使用terminal_manager关闭所有终端
            self.terminal_manager.close_all_terminals()
            self.patrol_processes.clear()
            
            print("✓ 巡逻会话已停止")
            return True
            
        except Exception as e:
            print(f"✗ 停止巡逻会话失败: {e}")
            return False
