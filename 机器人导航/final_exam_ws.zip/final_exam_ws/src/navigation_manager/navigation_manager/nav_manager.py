#!/usr/bin/env python3
"""
导航管理主入口脚本
"""
import sys
import os

# 获取当前文件的绝对路径
current_file = os.path.abspath(__file__)
current_dir = os.path.dirname(current_file)
package_root = os.path.dirname(current_dir)  # src/navigation_manager

# 设置Python路径
# 1. 首先添加当前包目录
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

# 2. 添加包的根目录
if package_root not in sys.path:
    sys.path.insert(0, package_root)

# 3. 检查是否在安装环境中运行
# 如果是通过ros2 run或直接运行可执行文件，可执行文件可能在bin/目录下
# 需要调整路径来找到真正的源码位置
exe_dir = os.path.dirname(sys.argv[0])
if exe_dir.endswith('bin'):
    # 如果是通过安装的可执行文件运行，需要找到源码位置
    ws_root = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
    src_path = os.path.join(ws_root, 'src/navigation_manager/navigation_manager')
    if src_path not in sys.path:
        sys.path.insert(0, src_path)

# 静默导入，不显示调试信息
try:
    from main_menu import MainMenu
    MainMenu  # 确保导入成功
except ImportError:
    # 尝试从navigation_manager包导入
    try:
        from navigation_manager.main_menu import MainMenu
    except ImportError as e:
        print(f"❌ 无法导入 MainMenu: {e}")
        print(f"当前Python路径:")
        for i, p in enumerate(sys.path[:10]):
            print(f"  {i+1}. {p}")
        sys.exit(1)

def main():
    """主函数"""
    try:
        # 创建并运行主菜单
        manager = MainMenu()
        manager.run()
    except KeyboardInterrupt:
        print("\n\n👋 程序被用户中断")
    except Exception as e:
        print(f"\n❌ 程序运行出错: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\n程序结束")

if __name__ == '__main__':
    main()
