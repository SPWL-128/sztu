#!/usr/bin/env python3
"""
建图处理模块 - 修复版本2
在用户停止建图时立即停止自动建图节点
"""
import subprocess
import os
import time
import threading
import sys

class MappingHandler:
    def __init__(self, terminal_manager, map_utils):
        self.terminal_manager = terminal_manager
        self.map_utils = map_utils
        self.mapping_processes = []
        self.auto_mapping_process = None  # 单独保存自动建图节点进程
        self.mapping_timeout = 300  # 5分钟默认超时
        self.user_stopped_flag = False  # 用户停止标志
        
    def start_mapping_session(self):
        """启动建图会话，打开四个终端（全部使用root）"""
        print("="*60)
        print("开始建图会话")
        print("所有终端将以root权限运行")
        print("="*60)
        
        # 获取工作空间目录
        ws_dir = "/home/vboxuser/final_exam_ws"
        
        try:
            # 终端1: Gazebo仿真 - 使用root终端
            print("\n启动Gazebo仿真（root权限）...")
            gazebo_process = self.terminal_manager.open_terminal_simple(
                title="Gazebo仿真 [ROOT]",
                command="ros2 launch fishbot_description gazebo_sim.launch.py",
                work_dir=ws_dir
            )
            self.mapping_processes.append(gazebo_process)
            time.sleep(15)
            
            # 检查Gazebo是否成功启动
            gazebo_ready = self.check_gazebo_ready()
            if not gazebo_ready:
                print("⚠️  Gazebo可能启动失败，尝试继续...")
            
            # 终端2: SLAM建图 - 使用root终端
            print("启动SLAM建图（root权限）...")
            slam_process = self.terminal_manager.open_terminal_simple(
                title="SLAM建图 [ROOT]",
                command="ros2 launch slam_toolbox online_async_launch.py slam_params_file:=/opt/ros/humble/share/slam_toolbox/config/mapper_params_online_async.yaml",
                work_dir=ws_dir
            )
            self.mapping_processes.append(slam_process)
            
            # 检查SLAM节点是否成功启动
            slam_ready = self.check_slam_ready()
            if not slam_ready:
                print("⚠️  SLAM节点可能启动失败，尝试继续...")
            else:
                print("✅ SLAM节点启动成功")
            
            time.sleep(10)
            
            # 终端3: RViz建图模式 - 使用root终端
            print("启动RViz建图（root权限）...")
            rviz_process = self.terminal_manager.open_terminal_simple(
                title="RViz建图 [ROOT]",
                command="rviz2 -d /home/vboxuser/final_exam_ws/src/navigation_manager/config/mapping_rviz.rviz",
                work_dir=ws_dir
            )
            self.mapping_processes.append(rviz_process)
            time.sleep(5)
            
            # 终端4: 自动建图节点 - 使用root终端
            print("启动自动建图节点（root权限）...")
            mapping_process = self.terminal_manager.open_terminal_simple(
                title="自动建图节点 [ROOT]",
                command="ros2 run my_patrol auto_mapping_node",
                work_dir=ws_dir
            )
            self.mapping_processes.append(mapping_process)
            self.auto_mapping_process = mapping_process  # 单独保存自动建图节点进程
            
            print("\n" + "="*60)
            print("✓ 建图环境已启动，打开4个终端（全部ROOT权限）：")
            print("  1. Gazebo仿真")
            print("  2. SLAM建图")
            print("  3. RViz建图")
            print("  4. 自动建图节点")
            print("="*60)
            print("\n🤖 机器人开始自动建图...")
            print("注意：所有终端都以root权限运行")
            print("="*60)
            
            return True
            
        except Exception as e:
            print(f"✗ 启动建图会话失败: {e}")
            return False
    
    def check_gazebo_ready(self):
        """检查Gazebo是否成功启动"""
        try:
            result = subprocess.run(
                "sudo pgrep -f gazebo",
                shell=True,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                pids = result.stdout.strip().split('\n')
                print(f"✓ Gazebo进程已启动 (PID: {', '.join(pids)})")
                return True
            else:
                print("⚠️  未找到Gazebo进程")
                return False
                
        except Exception as e:
            print(f"✗ 检查Gazebo状态失败: {e}")
            return False
    
    def check_slam_ready(self):
        """检查SLAM节点是否成功启动"""
        import time
        print("检查SLAM节点状态...")
        
        # 等待一段时间让SLAM节点启动
        time.sleep(8)
        
        try:
            # 检查slam_toolbox节点
            result = subprocess.run(
                "bash -c 'source /opt/ros/humble/setup.bash && ros2 node list | grep -i slam'",
                shell=True,
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                nodes = result.stdout.strip().split('\n')
                print(f"✓ SLAM节点已启动: {', '.join(nodes)}")
                
                # 检查/map话题
                topic_check = subprocess.run(
                    "bash -c 'source /opt/ros/humble/setup.bash && ros2 topic list | grep -E \"^/map$\"'",
                    shell=True,
                    capture_output=True,
                    text=True
                )
                
                if topic_check.returncode == 0:
                    print("✓ /map话题已创建")
                    return True
                else:
                    print("⚠️  SLAM节点已启动但/map话题未创建")
                    return False
            else:
                print("⚠️  未找到SLAM节点")
                return False
                
        except Exception as e:
            print(f"✗ 检查SLAM状态失败: {e}")
            return False

    def monitor_mapping_simple(self):
        """简化的监控建图过程 - 在用户停止时立即停止自动建图节点"""
        print("\n" + "="*60)
        print("🔄 建图进行中...")
        print("="*60)
        print("提示:")
        print("1. 建图过程将持续5分钟")
        print("2. 按任意键然后按Enter可以提前停止建图")
        print("3. 停止建图后会自动停止机器人运动")
        print("4. 您可以在RViz中观察建图进度")
        print("="*60)
        
        start_time = time.time()
        timeout = self.mapping_timeout
        
        try:
            # 使用一个简单的输入等待
            print(f"\n⏰ 建图将持续 {timeout//60} 分钟，按任意键+Enter提前停止...")
            
            # 设置一个定时器，在超时时自动停止
            def timeout_callback():
                if not self.user_stopped_flag:
                    print(f"\n✅ 建图完成 (运行 {timeout} 秒)")
                    # 超时也停止自动建图节点
                    print("🛑 自动停止机器人运动...")
                    self.stop_auto_mapping_node()
            
            # 启动超时定时器
            timeout_timer = threading.Timer(timeout, timeout_callback)
            timeout_timer.daemon = True
            timeout_timer.start()
            
            # 等待用户输入
            try:
                user_input = input("\n按任意键然后按Enter停止建图，或等待时间结束: ")
                self.user_stopped_flag = True
                elapsed = int(time.time() - start_time)
                print(f"\n🛑 用户提前停止建图 (已运行 {elapsed} 秒)")
                timeout_timer.cancel()
                
                # 关键修复：立即停止自动建图节点
                print("🛑 正在停止机器人运动...")
                self.stop_auto_mapping_node()
                
                return True
                
            except KeyboardInterrupt:
                self.user_stopped_flag = True
                elapsed = int(time.time() - start_time)
                print(f"\n🛑 用户中断建图 (已运行 {elapsed} 秒)")
                timeout_timer.cancel()
                
                # 关键修复：立即停止自动建图节点
                print("🛑 正在停止机器人运动...")
                self.stop_auto_mapping_node()
                
                return True
                
        except Exception as e:
            print(f"\n❌ 监控建图过程失败: {e}")
            return False
    
    def monitor_mapping(self):
        """监控建图过程 - 使用改进的方法"""
        return self.monitor_mapping_simple()
    
    def stop_auto_mapping_node_by_cmd(self):
        """通过命令行停止自动建图节点"""
        print("\n🛑 通过命令行停止自动建图节点...")
        
        try:
            # 方法1: 查找并杀死auto_mapping_node进程
            print("   查找auto_mapping_node进程...")
            find_cmd = "ps aux | grep auto_mapping_node | grep -v grep"
            result = subprocess.run(find_cmd, shell=True, capture_output=True, text=True)
            
            if result.stdout.strip():
                lines = result.stdout.strip().split('\n')
                for line in lines:
                    parts = line.split()
                    if len(parts) >= 2:
                        pid = parts[1]
                        user = parts[0]
                        print(f"   找到进程 PID: {pid}, 用户: {user}")
                        
                        # 杀死进程
                        if user == "root":
                            kill_cmd = f"sudo kill -9 {pid}"
                        else:
                            kill_cmd = f"kill -9 {pid}"
                        
                        print(f"   执行: {kill_cmd}")
                        subprocess.run(kill_cmd, shell=True, check=False)
            
            # 方法2: 通过pkill命令
            print("   使用pkill命令...")
            subprocess.run("sudo pkill -f 'auto_mapping_node' 2>/dev/null || true", shell=True)
            subprocess.run("pkill -f 'auto_mapping_node' 2>/dev/null || true", shell=True)
            
            # 方法3: 通过ros2节点命令停止相关节点
            print("   停止相关ROS2节点...")
            try:
                # 检查是否有ROS2环境
                ws_dir = "/home/vboxuser/final_exam_ws"
                cmd = f"cd {ws_dir} && . /opt/ros/humble/setup.bash && . install/setup.bash && ros2 node list 2>/dev/null | grep -E 'auto_mapping_node' || true"
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                
                if result.stdout.strip():
                    nodes = result.stdout.strip().split('\n')
                    for node in nodes:
                        print(f"   停止节点: {node}")
                        stop_cmd = f"cd {ws_dir} && . /opt/ros/humble/setup.bash && . install/setup.bash && ros2 lifecycle set {node} shutdown 2>/dev/null || true"
                        subprocess.run(stop_cmd, shell=True)
            except:
                pass
            
            # 等待机器人停止
            print("   等待机器人停止运动...")
            time.sleep(3)
            
            print("✅ 自动建图节点已停止")
            return True
            
        except Exception as e:
            print(f"❌ 停止自动建图节点失败: {e}")
            return False
    
    def stop_auto_mapping_node(self):
        """停止自动建图节点，让机器人停止运动"""
        print("\n🛑 正在停止自动建图节点...")
        
        try:
            # 1. 先尝试停止终端进程
            if self.auto_mapping_process and self.auto_mapping_process.poll() is None:
                print("   终止自动建图节点的终端进程...")
                self.auto_mapping_process.terminate()
                time.sleep(1)
                
                if self.auto_mapping_process.poll() is None:
                    print("   强制杀死自动建图节点的终端进程...")
                    self.auto_mapping_process.kill()
                    time.sleep(1)
            
            # 2. 通过命令行确保进程被杀死
            self.stop_auto_mapping_node_by_cmd()
            
            # 3. 等待地图数据稳定
            print("⏳ 等待5秒让地图数据稳定...")
            for i in range(5, 0, -1):
                print(f"   {i}秒...")
                time.sleep(1)
            
            return True
            
        except Exception as e:
            print(f"❌ 停止自动建图节点失败: {e}")
            return False
    
    def stop_mapping_session(self):
        """停止建图会话，关闭所有终端"""
        print("\n正在停止建图会话...")
        
        try:
            # 注意：这里不再单独调用stop_auto_mapping_node，因为可能在监控中已经调用了
            # 但为了确保，我们还是检查一下
            
            # 使用terminal_manager关闭所有终端
            self.terminal_manager.close_all_terminals()
            self.mapping_processes.clear()
            self.auto_mapping_process = None
            self.user_stopped_flag = False
            
            print("✓ 建图会话已停止")
            return True
            
        except Exception as e:
            print(f"✗ 停止建图会话失败: {e}")
            return False
    
    def ask_save_map(self):
        """询问是否保存地图"""
        print("\n" + "="*60)
        print("建图完成！是否保存地图？")
        print("="*60)
        
        while True:
            choice = input("\n请选择 (1=保存, 2=不保存): ").strip()
            
            if choice == "1":
                return True
            elif choice == "2":
                print("地图将不会被保存")
                return False
            else:
                print("无效选择，请输入1或2")
    
    def get_mapping_stats(self):
        """获取建图统计信息"""
        return {
            'duration': self.mapping_timeout,
            'status': 'completed'
        }
