#!/usr/bin/env python3
"""
主菜单模块 - 修复版本2
"""
import os
import sys
import time
from .terminal_manager import TerminalManager
from .map_utils import MapUtils
from .mapping_handler import MappingHandler
from .patrol_handler import PatrolHandler

class MainMenu:
    def __init__(self):
        # 初始化目录
        self.maps_dir = "/home/vboxuser/final_exam_ws/src/fishbot_navigation2/maps"
        self.ws_dir = "/home/vboxuser/final_exam_ws"
        
        # 初始化各个模块
        self.terminal_manager = TerminalManager()
        self.map_utils = MapUtils(self.maps_dir)
        self.mapping_handler = MappingHandler(self.terminal_manager, self.map_utils)
        self.patrol_handler = PatrolHandler(self.terminal_manager, self.map_utils)
        
    def show_banner(self):
        """显示程序横幅"""
        print("\n" + "="*60)
        print("        🤖 ROS2 机器人导航管理系统 - 一键操作版")
        print("="*60)
    
    def show_main_menu(self):
        """显示主菜单"""
        print("\n请选择操作:")
        print("="*60)
        print("1. 新建地图并进行巡逻")
        print("2. 使用已有地图进行巡逻")
        print("3. 查看已有地图列表")
        print("4. 删除地图文件")
        print("5. 退出系统")
        print("="*60)
    
    def run(self):
        """运行主菜单循环"""
        self.show_banner()
        
        while True:
            self.show_main_menu()
            choice = input("请输入选项 (1-5): ").strip()
            
            if choice == "1":
                self.mapping_and_patrol()
            elif choice == "2":
                self.patrol_with_existing_map()
            elif choice == "3":
                self.list_maps()
            elif choice == "4":
                self.delete_map()
            elif choice == "5":
                self.exit_system()
                break
            else:
                print("❌ 无效选择，请重新输入")
    
    def mapping_and_patrol(self):
        """新建地图并进行巡逻 - 修复版本，在保存地图前停止自动建图节点"""
        print("\n" + "="*60)
        print("选项1: 新建地图并进行巡逻")
        print("="*60)
        
        try:
            # 启动建图会话
            if not self.mapping_handler.start_mapping_session():
                print("❌ 启动建图失败")
                return
            
            # 监控建图过程
            user_stopped = self.mapping_handler.monitor_mapping()
            
            # 询问是否保存地图（此时建图进程还在运行）
            if self.mapping_handler.ask_save_map():
                # 生成地图名称
                map_name = self.map_utils.generate_map_name()
                print(f"\n正在保存地图: {map_name}")
                
                # 关键修复：在保存地图前停止自动建图节点
                
                # 保存地图（此时自动建图节点已停止，但其他建图进程还在运行）
                if self.map_utils.save_map(map_name):
                    print(f"✅ 地图保存成功: {map_name}")
                    # 停止建图会话
                    self.mapping_handler.stop_mapping_session()
                    # 使用新保存的地图进行巡逻
                    self.start_patrol(map_name)
                else:
                    print("❌ 地图保存失败")
                    # 停止建图会话
                    self.mapping_handler.stop_mapping_session()
                    if input("\n是否使用已有地图进行巡逻? (y/n): ").lower() == 'y':
                        self.patrol_with_existing_map()
            else:
                print("地图未保存")
                # 停止建图会话
                self.mapping_handler.stop_mapping_session()
                if input("\n是否使用已有地图进行巡逻? (y/n): ").lower() == 'y':
                    self.patrol_with_existing_map()
                    
        except KeyboardInterrupt:
            print("\n\n⚠️  用户中断操作")
            self.mapping_handler.stop_mapping_session()
        except Exception as e:
            print(f"\n❌ 操作失败: {e}")
            self.mapping_handler.stop_mapping_session()
    
    # 其他方法保持不变...
    def patrol_with_existing_map(self):
        """使用已有地图进行巡逻"""
        print("\n" + "="*60)
        print("选项2: 使用已有地图进行巡逻")
        print("="*60)
        
        # 选择地图
        selected_map = self.select_map_interactive()
        if selected_map is None:
            return
        
        # 开始巡逻
        self.start_patrol(selected_map)
    
    def list_maps(self):
        """列出所有地图"""
        print("\n" + "="*60)
        print("选项3: 查看已有地图列表")
        print("="*60)
        
        maps = self.map_utils.list_available_maps()
        
        if not maps:
            print("📭 没有找到地图文件")
            print("请先使用选项1创建地图")
        else:
            print(f"🗺️  发现 {len(maps)} 个地图文件:")
            print("-"*60)
            
            for i, map_name in enumerate(maps, 1):
                info = self.map_utils.get_map_info(map_name)
                if info:
                    status = "✅" if info['valid'] else "❌"
                    print(f"{i:2d}. {status} {map_name}")
                    print(f"    创建时间: {info['created']}")
                    print(f"    分辨率: {info['resolution']}")
                    print(f"    原点: {info['origin']}")
                    print()
                else:
                    print(f"{i:2d}. ❌ {map_name} (信息读取失败)")
        
        input("\n按Enter键返回主菜单...")
    
    def delete_map(self):
        """删除地图文件"""
        print("\n" + "="*60)
        print("选项4: 删除地图文件")
        print("="*60)
        
        maps = self.map_utils.list_available_maps()
        
        if not maps:
            print("📭 没有找到可删除的地图文件")
            return
        
        print("请选择要删除的地图:")
        print("-"*60)
        
        for i, map_name in enumerate(maps, 1):
            print(f"{i:2d}. {map_name}")
        
        print("-"*60)
        
        try:
            choice = int(input("请输入地图编号 (0取消): "))
            
            if choice == 0:
                print("操作取消")
                return
            
            if 1 <= choice <= len(maps):
                map_name = maps[choice-1]
                
                confirm = input(f"\n⚠️  确认删除地图 '{map_name}'? (y/n): ").lower()
                
                if confirm == 'y':
                    if self.map_utils.delete_map(map_name):
                        print(f"✅ 地图 '{map_name}' 已删除")
                    else:
                        print(f"❌ 删除地图 '{map_name}' 失败")
                else:
                    print("操作取消")
            else:
                print("❌ 无效的地图编号")
                
        except ValueError:
            print("❌ 请输入有效数字")
        except Exception as e:
            print(f"❌ 删除失败: {e}")
    
    def select_map_interactive(self):
        """交互式选择地图"""
        maps = self.map_utils.list_available_maps()
        
        if not maps:
            print("📭 没有找到地图文件")
            print("请先使用选项1创建地图")
            return None
        
        while True:
            print("\n可用地图列表:")
            print("-"*60)
            
            for i, map_name in enumerate(maps, 1):
                info = self.map_utils.get_map_info(map_name)
                if info and info['valid']:
                    print(f"{i:2d}. ✅ {map_name} ({info['created']})")
                else:
                    print(f"{i:2d}. ❌ {map_name} (文件不完整)")
            
            print("-"*60)
            
            try:
                choice = input("请输入地图编号 (0取消): ").strip()
                
                if choice == "0":
                    print("操作取消")
                    return None
                
                choice_num = int(choice)
                
                if 1 <= choice_num <= len(maps):
                    selected_map = maps[choice_num-1]
                    
                    # 验证地图文件
                    is_valid, message = self.map_utils.check_map_files(selected_map)
                    
                    if is_valid:
                        print(f"✅ 已选择地图: {selected_map}")
                        return selected_map
                    else:
                        print(f"❌ 地图文件不完整: {message}")
                        print("请选择其他地图")
                else:
                    print(f"❌ 请输入 1-{len(maps)} 之间的数字")
                    
            except ValueError:
                print("❌ 请输入有效数字")
            except Exception as e:
                print(f"❌ 选择失败: {e}")
    
    def start_patrol(self, map_name):
        """启动巡逻"""
        print(f"\n🚀 准备启动巡逻，使用地图: {map_name}")
        
        try:
            if not self.patrol_handler.start_patrol_session(map_name):
                print("❌ 启动巡逻失败")
                return
            
            print("\n" + "="*60)
            print("巡逻已启动!")
            print("="*60)
            print("\n操作说明:")
            print("1. 巡逻会在多个目标点之间循环")
            print("2. 您可以在终端中观察机器人运动")
            print("3. 按Enter键可以停止巡逻并退出程序")
            print("="*60)
            
            # 等待用户决定停止
            input("\n按Enter键停止巡逻并退出程序...")
            
            # 停止巡逻
            self.patrol_handler.stop_patrol_session()
            print("\n✅ 巡逻已停止，程序退出")
            
            # 直接退出程序
            import sys
            sys.exit(0)
            
        except KeyboardInterrupt:
            print("\n\n⚠️  用户中断巡逻")
            self.patrol_handler.stop_patrol_session()
            sys.exit(0)
        except Exception as e:
            print(f"\n❌ 巡逻失败: {e}")
            self.patrol_handler.stop_patrol_session()
            sys.exit(1)
    
    def exit_system(self):
        """退出系统"""
        print("\n" + "="*60)
        print("感谢使用 ROS2 机器人导航管理系统")
        print("再见! 👋")
        print("="*60)
        
        # 确保所有终端已关闭
        self.terminal_manager.close_all_terminals()
