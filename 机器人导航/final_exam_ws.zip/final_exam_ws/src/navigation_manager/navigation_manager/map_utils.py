#!/usr/bin/env python3
"""
地图工具模块
负责地图的扫描、保存、管理
"""
import os
import glob
from datetime import datetime
import subprocess
import time
import yaml

class MapUtils:
    def __init__(self, maps_dir):
        self.maps_dir = maps_dir
        if not os.path.exists(self.maps_dir):
            os.makedirs(self.maps_dir)
        
    def list_available_maps(self):
        """列出所有可用地图"""
        maps = []
        
        try:
            # 扫描maps目录下的所有.yaml文件
            for yaml_file in glob.glob(os.path.join(self.maps_dir, "*.yaml")):
                map_name = os.path.splitext(os.path.basename(yaml_file))[0]
                maps.append(map_name)
            
            # 按时间排序（如果文件名包含时间戳）
            maps.sort()
            
            return sorted(maps)
            
        except Exception as e:
            print(f"✗ 扫描地图失败: {e}")
            return []
    
    def get_map_info(self, map_name):
        """获取地图详细信息"""
        yaml_path = os.path.join(self.maps_dir, f"{map_name}.yaml")
        if not os.path.exists(yaml_path):
            return None
        
        try:
            with open(yaml_path, 'r') as f:
                map_data = yaml.safe_load(f)
            
            # 获取文件修改时间
            mtime = os.path.getmtime(yaml_path)
            create_time = datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S")
            
            # 检查PGM文件是否存在
            pgm_path = os.path.join(self.maps_dir, map_data.get('image', ''))
            pgm_exists = os.path.exists(pgm_path)
            
            return {
                'name': map_name,
                'yaml_path': yaml_path,
                'pgm_path': pgm_path if pgm_exists else None,
                'created': create_time,
                'resolution': map_data.get('resolution', '未知'),
                'origin': map_data.get('origin', '未知'),
                'valid': pgm_exists
            }
            
        except Exception as e:
            print(f"✗ 读取地图信息失败 {map_name}: {e}")
            return None
    
    def generate_map_name(self):
        """生成按时间戳命名的地图名称"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"map_{timestamp}"
    
    def save_map(self, map_name):
        """保存当前地图"""
        try:
            map_path = os.path.join(self.maps_dir, map_name)
            
            print(f"正在保存地图: {map_name}")
            print("注意：正在尝试保存地图，请确保SLAM节点正在运行...")
            
            # 构建完整的保存命令
            save_cmd = (
                "bash -c '"
                "cd /home/vboxuser/final_exam_ws && "
                ". /opt/ros/humble/setup.bash && "
                ". install/setup.bash && "
                f"ros2 run nav2_map_server map_saver_cli -f {map_path} "
                "--ros-args -p save_map_timeout:=30.0'"
            )
            
            # 运行保存命令
            print(f"执行命令: {save_cmd}")
            returncode, stdout, stderr = self._run_command_with_timeout(save_cmd, timeout=40)
            
            if returncode == 0:
                print(f"✓ 地图保存成功: {map_name}")
                print(f"输出: {stdout}")
                
                # 验证文件是否创建
                yaml_file = f"{map_path}.yaml"
                pgm_file = f"{map_path}.pgm"
                
                if os.path.exists(yaml_file) and os.path.exists(pgm_file):
                    print(f"  - YAML文件: {yaml_file}")
                    print(f"  - PGM文件: {pgm_file}")
                    return True
                else:
                    print(f"✗ 地图文件创建不完整")
                    print(f"  YAML存在: {os.path.exists(yaml_file)}")
                    print(f"  PGM存在: {os.path.exists(pgm_file)}")
                    return False
            else:
                print(f"✗ 地图保存失败，返回码: {returncode}")
                print("常见原因：")
                print("1. /map话题不存在 - 请确保SLAM节点正在运行")
                print("2. 地图数据不稳定 - 请等待几秒后重试")
                print("3. 权限问题 - 请检查目录权限")
                if stderr:
                    # 只显示关键错误信息
                    error_lines = stderr.split('\n')
                    for line in error_lines:
                        if 'ERROR' in line or 'Failed' in line:
                            print(f"  关键错误: {line}")
                return False
                
        except Exception as e:
            print(f"✗ 地图保存过程出错: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def delete_map(self, map_name):
        """删除地图文件"""
        try:
            yaml_file = os.path.join(self.maps_dir, f"{map_name}.yaml")
            pgm_file = os.path.join(self.maps_dir, f"{map_name}.pgm")
            
            files_deleted = []
            
            if os.path.exists(yaml_file):
                os.remove(yaml_file)
                files_deleted.append(yaml_file)
            
            if os.path.exists(pgm_file):
                os.remove(pgm_file)
                files_deleted.append(pgm_file)
            
            if files_deleted:
                print(f"✓ 已删除地图文件: {map_name}")
                return True
            else:
                print(f"✗ 地图文件不存在: {map_name}")
                return False
                
        except Exception as e:
            print(f"✗ 删除地图失败: {e}")
            return False
    
    def _run_command_with_timeout(self, command, timeout=10):
        """运行命令并设置超时"""
        try:
            print(f"执行命令: {command}")
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            stdout, stderr = process.communicate(timeout=timeout)
            print(f"命令输出: {stdout}")
            if stderr:
                print(f"命令错误: {stderr}")
            return process.returncode, stdout, stderr
            
        except subprocess.TimeoutExpired:
            process.kill()
            return -1, "", f"命令超时 (>{timeout}秒)"
        except Exception as e:
            return -1, "", str(e)
    
    def check_map_files(self, map_name):
        """检查地图文件是否完整"""
        yaml_file = os.path.join(self.maps_dir, f"{map_name}.yaml")
        pgm_file = os.path.join(self.maps_dir, f"{map_name}.pgm")
        
        if not os.path.exists(yaml_file):
            return False, f"YAML文件不存在: {yaml_file}"
        
        if not os.path.exists(pgm_file):
            return False, f"PGM文件不存在: {pgm_file}"
        
        return True, "地图文件完整"
