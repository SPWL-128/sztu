#!/usr/bin/env python3
"""
导航管理主入口脚本
"""
import sys
import os

# 获取当前脚本的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 添加包的父目录到系统路径
sys.path.insert(0, os.path.join(current_dir, '..'))
sys.path.insert(0, os.path.join(current_dir, '..', 'navigation_manager'))

from navigation_manager.main_menu import MainMenu

def main():
    try:
        # 创建并运行主菜单
        manager = MainMenu()
        manager.run()
    except KeyboardInterrupt:
        print("\n\n👋 程序被用户中断")
    except Exception as e:
        print(f"\n❌ 程序运行出错: {e}")
        import traceback
        traceback.print_exc()
    finally:
        print("\n程序结束")

if __name__ == '__main__':
    main()
