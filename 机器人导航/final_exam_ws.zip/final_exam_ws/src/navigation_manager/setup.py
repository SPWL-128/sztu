from setuptools import setup
import os
from glob import glob

package_name = 'navigation_manager'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'config'), glob('config/*')),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.py')),
        (os.path.join('share', package_name, 'resource'), glob('resource/*')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='user',
    maintainer_email='user@todo.todo',
    description='Integrated navigation manager for mapping and patrolling',
    license='TODO',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'nav_manager = navigation_manager.nav_manager:main',
        ],
    },
)
