#!/usr/bin/env python3
"""
改进的清理脚本 - 更彻底地清理Gazebo和ROS2进程
"""
import subprocess
import os
import time
import signal

def get_gazebo_processes():
    """获取所有Gazebo相关进程的详细信息"""
    try:
        # 使用ps命令获取进程信息
        cmd = "ps aux | grep -E '(gzserver|gzclient|gazebo)' | grep -v grep"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        processes = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split()
                if len(parts) >= 2:
                    pid = parts[1]
                    command = ' '.join(parts[10:])
                    processes.append({
                        'pid': pid,
                        'command': command
                    })
        return processes
    except Exception as e:
        print(f"获取进程信息失败: {e}")
        return []

def get_ros2_processes():
    """获取所有ROS2相关进程的详细信息"""
    try:
        # 获取ros2相关进程
        cmd = "ps aux | grep -E '(ros2|nav2|rviz2|slam_toolbox)' | grep -v grep"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        processes = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split()
                if len(parts) >= 2:
                    pid = parts[1]
                    command = ' '.join(parts[10:])
                    processes.append({
                        'pid': pid,
                        'command': command
                    })
        return processes
    except Exception as e:
        print(f"获取ROS2进程信息失败: {e}")
        return []

def kill_process_by_pid(pid, force=False):
    """通过PID杀死进程"""
    try:
        if not pid or not pid.isdigit():
            return False
            
        print(f"  - 杀死进程 PID: {pid}")
        
        # 首先尝试SIGTERM（优雅退出）
        try:
            os.kill(int(pid), signal.SIGTERM)
            time.sleep(0.5)
            
            # 检查进程是否还存在
            check_cmd = f"ps -p {pid} > /dev/null 2>&1"
            if subprocess.call(check_cmd, shell=True) == 0:
                print(f"   进程 {pid} 仍在运行，发送SIGKILL")
                os.kill(int(pid), signal.SIGKILL)
        except ProcessLookupError:
            print(f"   进程 {pid} 已不存在")
            return True
        except Exception as e:
            print(f"   杀死进程 {pid} 失败: {e}")
            return False
            
        time.sleep(0.5)
        return True
        
    except Exception as e:
        print(f"   处理进程 {pid} 时出错: {e}")
        return False

def clean_gazebo_processes():
    """清理Gazebo相关进程"""
    print("🧹 清理Gazebo相关进程...")
    
    processes = get_gazebo_processes()
    
    if not processes:
        print("  ✅ 没有发现Gazebo相关进程")
        return True
    
    print(f"  发现 {len(processes)} 个Gazebo相关进程:")
    for proc in processes:
        print(f"    PID: {proc['pid']}, 命令: {proc['command'][:50]}...")
    
    success = True
    for proc in processes:
        if not kill_process_by_pid(proc['pid']):
            success = False
    
    # 再次检查是否还有残留
    time.sleep(1)
    remaining = get_gazebo_processes()
    if remaining:
        print(f"  ⚠️  仍有 {len(remaining)} 个Gazebo进程残留，尝试强制清理...")
        for proc in remaining:
            subprocess.run(f"sudo kill -9 {proc['pid']}", shell=True)
    
    time.sleep(1)
    remaining = get_gazebo_processes()
    if remaining:
        print(f"  ❌ 仍有 {len(remaining)} 个Gazebo进程无法清理")
        return False
    else:
        print("  ✅ 所有Gazebo进程已清理")
        return success

def clean_ros2_processes():
    """清理ROS2相关进程"""
    print("🧹 清理ROS2相关进程...")
    
    processes = get_ros2_processes()
    
    if not processes:
        print("  ✅ 没有发现ROS2相关进程")
        return True
    
    print(f"  发现 {len(processes)} 个ROS2相关进程:")
    for proc in processes:
        print(f"    PID: {proc['pid']}, 命令: {proc['command'][:50]}...")
    
    success = True
    for proc in processes:
        if not kill_process_by_pid(proc['pid']):
            success = False
    
    # 再次检查是否还有残留
    time.sleep(1)
    remaining = get_ros2_processes()
    if remaining:
        print(f"  ⚠️  仍有 {len(remaining)} 个ROS2进程残留，尝试强制清理...")
        for proc in remaining:
            subprocess.run(f"sudo kill -9 {proc['pid']}", shell=True)
    
    time.sleep(1)
    remaining = get_ros2_processes()
    if remaining:
        print(f"  ❌ 仍有 {len(remaining)} 个ROS2进程无法清理")
        return False
    else:
        print("  ✅ 所有ROS2进程已清理")
        return success

def main():
    print("="*60)
    print("       🤖 改进的Gazebo/ROS2清理工具")
    print("="*60)
    
    # 获取当前进程信息
    current_pid = os.getpid()
    print(f"当前进程PID: {current_pid}")
    
    # 清理Gazebo进程
    gazebo_success = clean_gazebo_processes()
    
    # 清理ROS2进程
    ros2_success = clean_ros2_processes()
    
    # 额外的清理步骤
    print("🧹 执行额外清理步骤...")
    
    # 清理临时文件
    try:
        subprocess.run("rm -rf /tmp/gazebo-* 2>/dev/null", shell=True)
        subprocess.run("rm -rf /tmp/ros-* 2>/dev/null", shell=True)
        print("  ✅ 临时文件已清理")
    except:
        pass
    
    print("="*60)
    if gazebo_success and ros2_success:
        print("✅ 所有进程已成功清理")
        return 0
    else:
        print("⚠️  清理过程中可能存在问题")
        return 1

if __name__ == "__main__":
    exit(main())
